import pygame

pygame.mixer.init()

menusound = pygame.mixer.Sound('Music/menu_soundtrack.mp3')
startintrosound = pygame.mixer.Sound('Music/intro.mp3')
start_game = pygame.mixer.Sound('Music/begin_game.mp3')