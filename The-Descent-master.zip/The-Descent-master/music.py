import pygame

pygame.mixer.init()

menusound = pygame.mixer.Sound('Music/menu_soundtrack.mp3')
startintrosound = pygame.mixer.Sound('Music/intro.mp3')