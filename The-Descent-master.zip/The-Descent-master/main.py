import pygame
import random
import CONFIG
from camera import *


pygame.init()
screen = pygame.display.set_mode(CONFIG.SCREEN.size)
clock = pygame.time.Clock()

import Actions, music, Sprites

smth = Sprites.Smth(CONFIG.SCREEN.size)
FPS = 200
i = 0
game_size = (3000, CONFIG.SCREEN.size[1])
v = 20
left = False
right = False
up = False
bg = pygame.Surface((CONFIG.SCREEN.size[0], CONFIG.SCREEN.size[1]))
bg.fill(pygame.Color(30, 30, 30))
sprites = pygame.sprite.Group()
hero = Sprites.Player(game_size)
sprites.add(hero)
sprites.add(smth)
camera = Camera(camera_configure, game_size, CONFIG.SCREEN.size) 

running = True
while running:

    for e in pygame.event.get():
        if e.type == pygame.KEYDOWN and e.key == pygame.K_DELETE:
            running = False
        
        elif e.type == pygame.KEYDOWN and e.key == pygame.K_RETURN:
            CONFIG.menu = False
            CONFIG.startgame = True
        
        elif CONFIG.startgame:
            if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                CONFIG.startgame = False
                CONFIG.menu = True
            elif e.type == pygame.KEYDOWN and (e.key == pygame.K_w or e.key == pygame.K_UP):
                up = True
            elif e.type == pygame.KEYDOWN and (e.key == pygame.K_a or e.key == pygame.K_LEFT):
                left = True
            elif e.type == pygame.KEYDOWN and (e.key == pygame.K_d or e.key == pygame.K_RIGHT):
                right = True
            elif e.type == pygame.KEYUP and (e.key == pygame.K_w or e.key == pygame.K_UP):
                up = False
            elif e.type == pygame.KEYUP and (e.key == pygame.K_a or e.key == pygame.K_LEFT):
                left = False
            elif e.type == pygame.KEYUP and (e.key == pygame.K_d or e.key == pygame.K_RIGHT):
                right = False
    
    # START INTRO
    if CONFIG.startintro_1:
        music.startintrosound.play()
        screen.fill((0, 0, 0))
        Actions.startintro(screen, CONFIG.SCREEN.size, i) 
        if i < 140:
            i += v / FPS
        if i >= 140:
            CONFIG.startintro_1 = False
            CONFIG.startintro_2 = True
    elif CONFIG.startintro_2:
        screen.fill((0, 0, 0))
        Actions.startintro(screen, CONFIG.SCREEN.size, i) 
        if i > 0:
            i -= (v + 20) / FPS
        if i <= 3:
            CONFIG.startintro_2 = False
            CONFIG.startintro_3 = True
            i = 1
    elif CONFIG.startintro_3:
        music.startintrosound.stop()
        music.menusound.play(-1)
        screen.fill((0, 0, 0))
        if i < 140:
            i += v / FPS
        Actions.maincaption(screen, CONFIG.SCREEN.size, i)
        if i >= 140:
            CONFIG.startintro_3 = False
            CONFIG.menu = True
    
    # MAIN MENU
    if CONFIG.menu:
        if CONFIG.fmenu:
            music.menusound.play(-1)
        screen.fill((0, 0, 0))
        Actions.maincaption(screen, CONFIG.SCREEN.size, 139)
        Actions.pressenter(screen, CONFIG.SCREEN.size, 139)
        CONFIG.menu = False

    # START GAME
    if CONFIG.startgame:
        CONFIG.fmenu = True
        music.menusound.stop()
        screen.fill((35, 35, 35))
        sprites.draw(screen)
        screen.blit(bg, (0,0))
        camera.update(hero)
        hero.update(left, right, up)
        for sprite in sprites:
            screen.blit(sprite.image, camera.apply(sprite))
    clock.tick(FPS)
    pygame.display.flip()

pygame.quit()